/**
 * DiscWallet — transaction building & signing.
 *
 * Pure functions over Uint8Array so they run in both browser and Node
 * (vitest). Signing happens CLIENT-SIDE with the disc-derived keys; the
 * server only relays pre-signed raw transactions to public RPCs.
 *
 *   SOL → legacy System Program transfer, ed25519-signed (tweetnacl)
 *   EVM → EIP-1559 (type 2) transfer, secp256k1-signed (@noble/secp256k1)
 *   BTC → intentionally NOT supported for sending (UTXO coin-selection and
 *         PSBT signing are out of scope); receive-only.
 */

import nacl from "tweetnacl";
import bs58 from "bs58";
import * as secp from "@noble/secp256k1";
import { keccak_256 } from "@noble/hashes/sha3.js";
import { sha256 as nobleSha256 } from "@noble/hashes/sha2.js";
import { hmac } from "@noble/hashes/hmac.js";

// noble-secp256k1 v3 needs hash implementations injected once.
if (!secp.hashes.sha256) {
  secp.hashes.sha256 = nobleSha256;
  secp.hashes.hmacSha256 = (key: Uint8Array, msg: Uint8Array) =>
    hmac(nobleSha256, key, msg);
}

/* ------------------------------ hex helpers ------------------------------ */

export function hexToBytes(hex: string): Uint8Array {
  const clean = hex.startsWith("0x") ? hex.slice(2) : hex;
  const padded = clean.length % 2 ? "0" + clean : clean;
  const out = new Uint8Array(padded.length / 2);
  for (let i = 0; i < out.length; i++) {
    out[i] = parseInt(padded.slice(i * 2, i * 2 + 2), 16);
  }
  return out;
}

export function bytesToHex0x(bytes: Uint8Array): string {
  return (
    "0x" +
    Array.from(bytes)
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")
  );
}

/* ============================== SOLANA ============================== */

/**
 * Build and sign a legacy Solana System Program transfer.
 * Message layout (legacy, no address table lookups):
 *   header(3) | acct_count | accounts | recentBlockhash(32) | instructions
 */
export function buildSolanaTransfer(params: {
  fromSecretKey: Uint8Array; // 64-byte nacl secret key
  toAddress: string; // base58
  lamports: bigint;
  recentBlockhash: string; // base58
}): { rawBase64: string; signatureBase58: string } {
  const { fromSecretKey, toAddress, lamports, recentBlockhash } = params;
  const fromPub = fromSecretKey.slice(32); // ed25519 pubkey half
  const toPub = bs58.decode(toAddress);
  if (toPub.length !== 32) throw new Error("Invalid Solana recipient address");
  const blockhash = bs58.decode(recentBlockhash);
  if (blockhash.length !== 32) throw new Error("Invalid recent blockhash");

  const SYSTEM_PROGRAM = new Uint8Array(32); // all zeros

  const sameAccount =
    toPub.length === fromPub.length && toPub.every((b, i) => b === fromPub[i]);

  // Account list: [payer(signer,writable), to(writable), systemProgram]
  const accounts = sameAccount
    ? [fromPub, SYSTEM_PROGRAM]
    : [fromPub, toPub, SYSTEM_PROGRAM];
  const numRequiredSignatures = 1;
  const numReadonlySigned = 0;
  const numReadonlyUnsigned = 1; // system program

  // Instruction: programIdIndex = last, accounts = [0, toIndex], data = transfer
  const toIndex = sameAccount ? 0 : 1;
  const programIndex = accounts.length - 1;

  // System transfer instruction data: u32 LE tag (2) + u64 LE lamports
  const data = new Uint8Array(12);
  new DataView(data.buffer).setUint32(0, 2, true);
  new DataView(data.buffer).setBigUint64(4, lamports, true);

  const parts: number[] = [];
  parts.push(numRequiredSignatures, numReadonlySigned, numReadonlyUnsigned);
  parts.push(accounts.length);
  for (const a of accounts) parts.push(...Array.from(a));
  parts.push(...Array.from(blockhash));
  parts.push(1); // one instruction
  parts.push(programIndex);
  parts.push(2); // two account indices
  parts.push(0, toIndex);
  parts.push(data.length);
  parts.push(...Array.from(data));

  const message = new Uint8Array(parts);
  const signature = nacl.sign.detached(message, fromSecretKey);

  // Wire format: sig_count | sigs | message
  const tx = new Uint8Array(1 + 64 + message.length);
  tx[0] = 1;
  tx.set(signature, 1);
  tx.set(message, 65);

  // base64 without Buffer (browser-safe)
  let bin = "";
  for (let i = 0; i < tx.length; i++) bin += String.fromCharCode(tx[i]);
  const rawBase64 =
    typeof btoa !== "undefined"
      ? btoa(bin)
      : // Node fallback
        // eslint-disable-next-line no-undef
        Buffer.from(tx).toString("base64");

  return { rawBase64, signatureBase58: bs58.encode(signature) };
}

/* ================================ EVM ================================ */

/** Minimal RLP encoding (strings/byte arrays and nested lists). */
type RlpInput = Uint8Array | RlpInput[];

function rlpEncode(input: RlpInput): Uint8Array {
  if (input instanceof Uint8Array) {
    if (input.length === 1 && input[0] < 0x80) return input;
    return concat(encodeLength(input.length, 0x80), input);
  }
  const encodedItems = input.map(rlpEncode);
  const payload = concat(...encodedItems);
  return concat(encodeLength(payload.length, 0xc0), payload);
}

function encodeLength(len: number, offset: number): Uint8Array {
  if (len < 56) return new Uint8Array([len + offset]);
  const hex = len.toString(16);
  const lenBytes = hexToBytes(hex);
  return concat(new Uint8Array([lenBytes.length + offset + 55]), lenBytes);
}

function concat(...arrays: Uint8Array[]): Uint8Array {
  const total = arrays.reduce((n, a) => n + a.length, 0);
  const out = new Uint8Array(total);
  let off = 0;
  for (const a of arrays) {
    out.set(a, off);
    off += a.length;
  }
  return out;
}

/** big-endian minimal bytes of a bigint (empty for zero, per RLP rules) */
export function bigintToMinimalBytes(v: bigint): Uint8Array {
  if (v === BigInt(0)) return new Uint8Array(0);
  let hex = v.toString(16);
  if (hex.length % 2) hex = "0" + hex;
  return hexToBytes(hex);
}

export interface Eip1559Params {
  privateKey: Uint8Array;
  chainId: bigint;
  nonce: bigint;
  maxPriorityFeePerGas: bigint;
  maxFeePerGas: bigint;
  gasLimit: bigint;
  to: string; // 0x-prefixed
  value: bigint; // wei
}

/**
 * Build and sign an EIP-1559 (type 2) value transfer.
 * Returns the 0x-prefixed raw transaction for eth_sendRawTransaction.
 */
export function buildEip1559Transfer(params: Eip1559Params): { rawHex: string } {
  const {
    privateKey,
    chainId,
    nonce,
    maxPriorityFeePerGas,
    maxFeePerGas,
    gasLimit,
    to,
    value,
  } = params;

  const toBytes = hexToBytes(to);
  if (toBytes.length !== 20) throw new Error("Invalid EVM recipient address");

  const fields: RlpInput[] = [
    bigintToMinimalBytes(chainId),
    bigintToMinimalBytes(nonce),
    bigintToMinimalBytes(maxPriorityFeePerGas),
    bigintToMinimalBytes(maxFeePerGas),
    bigintToMinimalBytes(gasLimit),
    toBytes,
    bigintToMinimalBytes(value),
    new Uint8Array(0), // data
    [], // accessList
  ];

  const unsignedPayload = concat(new Uint8Array([2]), rlpEncode(fields));
  const digest = keccak_256(unsignedPayload);

  // noble v3: 'recovered' format = recovery(1) | r(32) | s(32)
  const recovered = secp.sign(digest, privateKey, {
    prehash: false,
    format: "recovered",
  }) as Uint8Array;
  const yParity = recovered[0];
  const r = recovered.slice(1, 33);
  const s = recovered.slice(33, 65);

  const signedFields: RlpInput[] = [
    ...fields,
    yParity === 0 ? new Uint8Array(0) : new Uint8Array([1]),
    stripLeadingZeros(r),
    stripLeadingZeros(s),
  ];

  const raw = concat(new Uint8Array([2]), rlpEncode(signedFields));
  return { rawHex: bytesToHex0x(raw) };
}

function stripLeadingZeros(bytes: Uint8Array): Uint8Array {
  let i = 0;
  while (i < bytes.length - 1 && bytes[i] === 0) i++;
  return bytes.slice(i);
}

/* ------------------------- validation helpers ------------------------- */

export function isValidSolAddress(addr: string): boolean {
  try {
    return bs58.decode(addr).length === 32;
  } catch {
    return false;
  }
}

export function isValidEvmAddress(addr: string): boolean {
  return /^0x[0-9a-fA-F]{40}$/.test(addr);
}

/** Parse a decimal amount string into base units (bigint), given decimals. */
export function parseAmount(amount: string, decimals: number): bigint {
  const trimmed = amount.trim();
  if (!/^\d+(\.\d+)?$/.test(trimmed)) throw new Error("Invalid amount");
  const [whole, frac = ""] = trimmed.split(".");
  if (frac.length > decimals) throw new Error("Too many decimal places");
  const fracPadded = frac.padEnd(decimals, "0");
  let scale = BigInt(1);
  for (let i = 0; i < decimals; i++) scale *= BigInt(10);
  return BigInt(whole) * scale + BigInt(fracPadded || "0");
}
