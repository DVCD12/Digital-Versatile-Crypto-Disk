/**
 * DiscWallet — multi-chain deterministic derivation.
 *
 * All chains derive from the SAME 32-byte disc fingerprint, like a hardware
 * wallet deriving every chain from one seed. Per-chain seeds are domain-
 * separated so keys are independent across curves:
 *
 *   chainSeed = SHA-256( "discwallet/v1/" + chainId + "\n" + fingerprint )
 *
 *   SOL  → ed25519  (tweetnacl)            → base58(pubkey)
 *   ETH  → secp256k1 → keccak256(pub[1:])[-20:] → EIP-55 checksum (also
 *          reused by every EVM chain: Polygon, Base)
 *   BTC  → secp256k1 → P2WPKH bech32 (bc1…)
 *
 * Pure functions over Uint8Array — safe in browser and Node (vitest).
 */

import nacl from "tweetnacl";
import bs58 from "bs58";
import * as secp from "@noble/secp256k1";
import { keccak_256, sha3_256 } from "@noble/hashes/sha3.js";
import { sha256 as nobleSha256 } from "@noble/hashes/sha2.js";
import { ripemd160 } from "@noble/hashes/legacy.js";
import { bech32 } from "@scure/base";

export type ChainId = "sol" | "eth" | "btc" | "polygon" | "base";

export interface ChainInfo {
  id: ChainId;
  name: string;
  ticker: string;
  /** Which derived address this chain uses. */
  addressKind: "sol" | "eth" | "btc";
  /** VFD accent for the chain LED. */
  color: string;
  decimals: number;
}

export const CHAINS: ChainInfo[] = [
  { id: "sol", name: "SOLANA", ticker: "SOL", addressKind: "sol", color: "#9945FF", decimals: 9 },
  { id: "eth", name: "ETHEREUM", ticker: "ETH", addressKind: "eth", color: "#627EEA", decimals: 18 },
  { id: "btc", name: "BITCOIN", ticker: "BTC", addressKind: "btc", color: "#F7931A", decimals: 8 },
  { id: "polygon", name: "POLYGON", ticker: "POL", addressKind: "eth", color: "#8247E5", decimals: 18 },
  { id: "base", name: "BASE", ticker: "ETH", addressKind: "eth", color: "#0052FF", decimals: 18 },
];

export interface MultiChainKeys {
  sol: { address: string; secretKey: Uint8Array };
  eth: { address: string; privateKey: Uint8Array };
  btc: { address: string; privateKey: Uint8Array };
}

/* ------------------------------- helpers -------------------------------- */

export function bytesToHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** Domain-separated per-chain seed from the disc fingerprint. */
function chainSeed(fingerprint: Uint8Array, domain: string): Uint8Array {
  const prefix = new TextEncoder().encode(`discwallet/v1/${domain}\n`);
  const material = new Uint8Array(prefix.length + fingerprint.length);
  material.set(prefix, 0);
  material.set(fingerprint, prefix.length);
  return nobleSha256(material);
}

/**
 * secp256k1 requires 1 <= key < curve order n. A SHA-256 output is outside
 * that range with probability ~2^-128; rehash until valid to stay total.
 */
function toValidSecpKey(seed: Uint8Array): Uint8Array {
  let key = seed;
  while (!secp.utils.isValidSecretKey(key)) {
    key = nobleSha256(key);
  }
  return key;
}

/* ----------------------------- ETH address ------------------------------ */

/** EIP-55 checksummed Ethereum address from a private key. */
function ethAddressFromPriv(priv: Uint8Array): string {
  const pub = secp.getPublicKey(priv, false); // 65 bytes, 0x04-prefixed
  const hash = keccak_256(pub.slice(1));
  const addr = bytesToHex(hash.slice(-20));
  // EIP-55 checksum
  const checksumHash = bytesToHex(keccak_256(new TextEncoder().encode(addr)));
  let out = "0x";
  for (let i = 0; i < addr.length; i++) {
    out += parseInt(checksumHash[i], 16) >= 8 ? addr[i].toUpperCase() : addr[i];
  }
  return out;
}

/* ----------------------------- BTC address ------------------------------ */

/** Native SegWit (P2WPKH, bech32 "bc1q…") address from a private key. */
function btcAddressFromPriv(priv: Uint8Array): string {
  const pub = secp.getPublicKey(priv, true); // 33 bytes compressed
  const h160 = ripemd160(nobleSha256(pub));
  return bech32.encode("bc", [0, ...bech32.toWords(h160)]);
}

/* ----------------------------- derivation ------------------------------- */

/** Derive all chain keys from the 32-byte disc fingerprint. */
export function deriveMultiChain(fingerprint: Uint8Array): MultiChainKeys {
  if (fingerprint.length !== 32) {
    throw new Error("fingerprint must be 32 bytes");
  }

  // Solana: ed25519 straight from the fingerprint (backwards compatible with
  // the original single-chain DiscWallet derivation — same disc, same SOL
  // address as before the multi-chain upgrade).
  const solPair = nacl.sign.keyPair.fromSeed(fingerprint);

  const ethPriv = toValidSecpKey(chainSeed(fingerprint, "eth"));
  const btcPriv = toValidSecpKey(chainSeed(fingerprint, "btc"));

  return {
    sol: { address: bs58.encode(solPair.publicKey), secretKey: solPair.secretKey },
    eth: { address: ethAddressFromPriv(ethPriv), privateKey: ethPriv },
    btc: { address: btcAddressFromPriv(btcPriv), privateKey: btcPriv },
  };
}

/** Address for a given chain id from derived keys (EVM chains share ETH). */
export function addressForChain(keys: MultiChainKeys, chain: ChainInfo): string {
  return keys[chain.addressKind].address;
}

// re-export for tests
export { sha3_256 };
