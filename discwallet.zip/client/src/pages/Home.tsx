/**
 * DiscWallet — DW-1000 main deck screen
 * Y2K Optical Deck: rack-unit faceplate, disc on the left, VFD readout right.
 * States: idle (insert a disc) → reading → loaded (wallet screen).
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Disc3, Eject, FolderOpen } from "@/components/deck-icons";
import DriveBay from "@/components/DriveBay";
import ChainReadout from "@/components/ChainReadout";
import {
  DiscWallet,
  deriveWallet,
  entriesFromFileList,
  isHandleReadable,
  nextSimulatedDisc,
  supportsDirectoryPicker,
  walkDirectoryHandle,
} from "@/lib/disc";

type DeckState = "idle" | "reading" | "loaded";

const CHASSIS_BG = "/manus-storage/chassis-bg_06f6133d.png";
const LOGO = "/manus-storage/discwallet-logo_d060021f.png";

export default function Home() {
  const [deck, setDeck] = useState<DeckState>("idle");
  const [wallet, setWallet] = useState<DiscWallet | null>(null);
  const [readProgress, setReadProgress] = useState(0);
  const [isSimulated, setIsSimulated] = useState(false);
  const [statusLine, setStatusLine] = useState("INSERT DISC TO CONTINUE");

  const handleRef = useRef<FileSystemDirectoryHandle | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const fsApiAvailable = supportsDirectoryPicker();

  /* ------------------------------- eject ------------------------------- */

  const eject = useCallback((reason?: string) => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
    handleRef.current = null;
    setWallet(null);
    setIsSimulated(false);
    setDeck("idle");
    setStatusLine(reason ?? "INSERT DISC TO CONTINUE");
  }, []);

  /* ------------------------ eject detection poll ----------------------- */

  const startPolling = useCallback(() => {
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      const h = handleRef.current;
      if (!h) return;
      const ok = await isHandleReadable(h);
      if (!ok) {
        toast.warning("MEDIA REMOVED — TRAY LOCKED", {
          description: "The disc is no longer readable. Wallet unloaded.",
        });
        eject("MEDIA REMOVED — INSERT DISC");
      }
    }, 4000);
  }, [eject]);

  useEffect(() => {
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  /* ---------------------------- disc loading --------------------------- */

  const finishLoad = useCallback(
    async (entries: string[], label: string, simulated: boolean) => {
      if (entries.length === 0) {
        toast.error("READ ERROR — BLANK MEDIA", {
          description: "No files found on the selected volume.",
        });
        eject("READ ERROR — INSERT DISC");
        return;
      }
      const w = await deriveWallet(entries, label);
      setWallet(w);
      setIsSimulated(simulated);
      setDeck("loaded");
      setStatusLine("TRAY LOCKED — WALLETS DERIVED FROM MEDIA FINGERPRINT");
    },
    [eject],
  );

  const readDisc = useCallback(async () => {
    if (!fsApiAvailable) {
      // Fallback: one-shot webkitdirectory read
      fileInputRef.current?.click();
      return;
    }
    try {
      // @ts-expect-error showDirectoryPicker not yet in TS lib
      const dir: FileSystemDirectoryHandle = await window.showDirectoryPicker({
        mode: "read",
      });
      setDeck("reading");
      setReadProgress(0);
      setStatusLine("READING MEDIA — DO NOT REMOVE DISC");
      const entries = await walkDirectoryHandle(dir, (n) => setReadProgress(n));
      handleRef.current = dir;
      await finishLoad(entries, dir.name || "UNTITLED DISC", false);
      startPolling();
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") {
        // user cancelled the picker — stay idle silently
        setDeck("idle");
        return;
      }
      toast.error("READ ERROR", {
        description: e instanceof Error ? e.message : "Could not read volume.",
      });
      eject("READ ERROR — INSERT DISC");
    }
  }, [fsApiAvailable, finishLoad, startPolling, eject]);

  const onFallbackFiles = useCallback(
    async (files: FileList | null) => {
      if (!files || files.length === 0) return;
      setDeck("reading");
      setReadProgress(0);
      setStatusLine("READING MEDIA — ONE-SHOT MODE");
      // small delay so the read animation is perceivable
      await new Promise((r) => setTimeout(r, 600));
      const { entries, label } = entriesFromFileList(files);
      setReadProgress(entries.length);
      await finishLoad(entries, label, false);
      toast.info("ONE-SHOT READ COMPLETE", {
        description:
          "This browser cannot monitor the drive. Eject detection is disabled.",
      });
    },
    [finishLoad],
  );

  const simulateDisc = useCallback(async () => {
    setDeck("reading");
    setReadProgress(0);
    setStatusLine("READING MEDIA — SIMULATION");
    const { entries, label } = nextSimulatedDisc();
    // simulate seek time with incremental progress
    for (let i = 1; i <= entries.length; i++) {
      setReadProgress(i);
      await new Promise((r) => setTimeout(r, 120));
    }
    await finishLoad(entries, label, true);
  }, [finishLoad]);

  /* ------------------------------- render ------------------------------ */

  const discState = deck === "reading" ? "reading" : deck === "loaded" ? "loaded" : "idle";

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center py-8 px-4"
      style={{
        backgroundImage: `linear-gradient(rgba(8,8,10,0.55), rgba(8,8,10,0.75)), url(${CHASSIS_BG})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {/* hidden fallback input */}
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        // @ts-expect-error non-standard attribute
        webkitdirectory=""
        directory=""
        multiple
        onChange={(e) => onFallbackFiles(e.target.files)}
      />

      {/* ============ RACK UNIT FACEPLATE ============ */}
      <div className="faceplate rounded-lg w-full max-w-5xl overflow-hidden">
        {/* -------- header strip -------- */}
        <header className="flex items-center justify-between px-5 py-3 border-b border-white/8">
          <div className="flex items-center gap-3">
            <div className="screw" />
            <img src={LOGO} alt="DVCD" className="h-8 w-8" />
            <div className="flex items-baseline gap-2">
              <span
                className="text-lg font-semibold tracking-[0.12em]"
                style={{ fontFamily: "Chakra Petch" }}
              >
                DVCD
              </span>
              <span className="engraved-label hidden sm:inline">DW-1000</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="engraved-label hidden sm:inline">ACTIVITY</span>
              <div
                className={`led ${
                  deck === "reading"
                    ? "led-on led-blink"
                    : deck === "loaded"
                      ? "led-on"
                      : "led-off"
                }`}
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="engraved-label hidden sm:inline">CHAINS</span>
              <div className={`led ${deck === "loaded" ? "led-green" : "led-off"}`} />
            </div>
            <div className="screw" />
          </div>
        </header>

        {/* -------- main deck area -------- */}
        <div className="grid md:grid-cols-[55%_45%] min-h-[460px]">
          {/* ===== LEFT: disc tray ===== */}
          <div className="relative flex flex-col items-center justify-center gap-6 p-8 border-b md:border-b-0 md:border-r border-white/8">
            {/* tray vents */}
            <div className="absolute top-4 left-6 right-6 flex justify-between opacity-40">
              {Array.from({ length: 14 }).map((_, i) => (
                <div key={i} className="w-px h-3 bg-white/20" />
              ))}
            </div>

            <DriveBay state={discState} size={264} />

            <div className="text-center space-y-1">
              <p className="vfd-text text-sm tracking-wider min-h-5">{statusLine}</p>
              {deck === "reading" && (
                <p className="text-xs text-muted-foreground font-mono">
                  ENTRIES READ: {readProgress}
                </p>
              )}
            </div>

            {/* transport buttons */}
            {deck === "idle" && (
              <div className="flex flex-col items-center gap-3">
                <button
                  onClick={readDisc}
                  className="hw-button flex items-center gap-2.5 px-8 py-3.5 rounded-md bg-primary text-primary-foreground font-semibold tracking-[0.1em] text-sm shadow-[0_4px_0_oklch(0.55_0.14_75),0_8px_20px_rgba(0,0,0,0.5)] active:shadow-[0_1px_0_oklch(0.55_0.14_75)]"
                  style={{ fontFamily: "Chakra Petch" }}
                >
                  <Disc3 className="h-4.5 w-4.5" />
                  READ DISC
                </button>
                <button
                  onClick={simulateDisc}
                  className="hw-button flex items-center gap-2 px-5 py-2 rounded-md bg-secondary text-secondary-foreground text-xs tracking-[0.12em] border border-white/10"
                  style={{ fontFamily: "Chakra Petch" }}
                >
                  <FolderOpen className="h-3.5 w-3.5" />
                  SIMULATE DISC
                </button>
                {!fsApiAvailable && (
                  <p className="text-[11px] text-muted-foreground max-w-60 text-center leading-relaxed">
                    Live drive monitoring requires Chrome or Edge. Your browser
                    will use a one-shot folder read instead.
                  </p>
                )}
              </div>
            )}

            {deck === "loaded" && (
              <button
                onClick={() => eject()}
                className="hw-button flex items-center gap-2.5 px-8 py-3 rounded-md bg-secondary text-secondary-foreground font-semibold tracking-[0.1em] text-sm border border-white/12 shadow-[0_4px_0_rgba(0,0,0,0.4)]"
                style={{ fontFamily: "Chakra Petch" }}
              >
                <Eject className="h-4 w-4" />
                EJECT
              </button>
            )}
          </div>

          {/* ===== RIGHT: VFD readout panel ===== */}
          <div className="flex flex-col p-6 gap-4">
            <div className="flex items-center justify-between">
              <span className="engraved-label">WALLET READOUT</span>
              {isSimulated && deck === "loaded" && (
                <span className="text-[10px] tracking-[0.15em] px-2 py-0.5 rounded border border-amber-led/40 text-amber-led/90">
                  SIMULATED MEDIA
                </span>
              )}
            </div>

            {deck !== "loaded" || !wallet ? (
              /* ---- empty readout ---- */
              <div className="vfd-panel rounded-md flex-1 flex flex-col items-center justify-center gap-3 p-6 tray-enter">
                <div className="vfd-text text-2xl tracking-[0.2em] opacity-60">
                  {deck === "reading" ? "READING…" : "NO MEDIA"}
                </div>
                <p className="text-xs text-muted-foreground text-center max-w-64 leading-relaxed">
                  {deck === "reading"
                    ? "Fingerprinting volume contents…"
                    : "Insert a disc to derive its wallets. Same disc, same wallets — on any machine, on every chain."}
                </p>
              </div>
            ) : (
              /* ---- loaded readout: multi-chain hardware-wallet panel ---- */
              <ChainReadout wallet={wallet} />
            )}
          </div>
        </div>

        {/* -------- footer strip -------- */}
        <footer className="flex items-center justify-between px-5 py-2.5 border-t border-white/8">
          <div className="flex items-center gap-3">
            <div className="screw" />
            <span className="engraved-label">
              OPTICAL MEDIA → SEED → SOL · ETH · BTC · POL · BASE
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="engraved-label hidden md:inline">
              DETERMINISTIC · NO DATABASE · NO CUSTODY
            </span>
            <div className="screw" />
          </div>
        </footer>
      </div>

      {/* how it works */}
      <p className="mt-6 max-w-xl text-center text-xs text-muted-foreground leading-relaxed">
        DVCD fingerprints the file structure of your disc (paths, sizes,
        volume label) and hashes it with SHA-256. That one fingerprint seeds
        every chain — ed25519 for Solana, secp256k1 for Ethereum, Bitcoin and
        EVM networks — exactly like a hardware wallet deriving all accounts
        from a single seed. The disc itself is the key: re-insert it on any
        machine to load the same wallets.
      </p>
    </div>
  );
}
