/**
 * DiscWallet — multi-chain VFD readout.
 * Hardware-wallet style: a chain selector row (like a Ledger's app list),
 * one active chain's balance + address, all derived from the same disc.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Check, Copy, RefreshCw } from "@/components/deck-icons";
import { CHAINS, ChainId, ChainInfo, addressForChain } from "@shared/chains";
import { DiscWallet, fetchBalance, fetchBalanceViaRelay, fetchChainBalance } from "@/lib/disc";
import SendReceivePanel from "@/components/SendReceivePanel";

type BalanceState =
  | { status: "loading" }
  | { status: "ok"; value: number }
  | { status: "error"; message: string };

interface Props {
  wallet: DiscWallet;
}

export default function ChainReadout({ wallet }: Props) {
  const [active, setActive] = useState<ChainId>("sol");
  const [balances, setBalances] = useState<Partial<Record<ChainId, BalanceState>>>({});
  const [copied, setCopied] = useState(false);
  const inFlight = useRef<Set<ChainId>>(new Set());

  const activeChain = CHAINS.find((c) => c.id === active)!;
  const activeAddress = addressForChain(wallet.chains, activeChain);
  const activeBalance = balances[active];

  /* ------------------------------ balances ------------------------------ */

  const loadBalance = useCallback(
    async (chain: ChainInfo, force = false) => {
      if (inFlight.current.has(chain.id)) return;
      inFlight.current.add(chain.id);
      setBalances((prev) =>
        force || !prev[chain.id] ? { ...prev, [chain.id]: { status: "loading" } } : prev,
      );
      const address = addressForChain(wallet.chains, chain);
      try {
        let value: number;
        if (chain.id === "sol") {
          // Direct public RPC first, relay fallback (403s browser origins).
          try {
            value = await fetchBalance(address);
          } catch {
            value = await fetchBalanceViaRelay(address);
          }
        } else {
          value = await fetchChainBalance(chain.id, address);
        }
        setBalances((prev) => ({ ...prev, [chain.id]: { status: "ok", value } }));
      } catch (e) {
        setBalances((prev) => ({
          ...prev,
          [chain.id]: {
            status: "error",
            message: e instanceof Error ? e.message : "RPC unreachable",
          },
        }));
      } finally {
        inFlight.current.delete(chain.id);
      }
    },
    [wallet],
  );

  // Load every chain's balance once when a disc is inserted.
  useEffect(() => {
    setBalances({});
    setActive("sol");
    CHAINS.filter((c, i, arr) => arr.findIndex((x) => x.id === c.id) === i).forEach((c) =>
      loadBalance(c, true),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wallet.fingerprintHex]);

  /* -------------------------------- copy -------------------------------- */

  const copyAddress = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(activeAddress);
      setCopied(true);
      toast.success(`${activeChain.name} ADDRESS COPIED`);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("CLIPBOARD UNAVAILABLE");
    }
  }, [activeAddress, activeChain]);

  /* ------------------------------- render ------------------------------- */

  const fmt = (chain: ChainInfo, b: BalanceState | undefined) => {
    if (!b || b.status === "loading") return "—.——————";
    if (b.status === "error") return "ERR";
    const digits = chain.id === "btc" ? 8 : 6;
    return b.value.toFixed(digits);
  };

  /** Compact balance for the selector row (like a Ledger app-list summary). */
  const fmtShort = (b: BalanceState | undefined) => {
    if (!b || b.status === "loading") return "—.——";
    if (b.status === "error") return "ERR";
    return b.value === 0 ? "0.00" : b.value.toFixed(b.value < 0.01 ? 4 : 2);
  };

  return (
    <div className="flex flex-col gap-3 flex-1 tray-enter">
      {/* ---- chain selector (hardware-wallet app list) ---- */}
      <div className="vfd-panel rounded-md p-2">
        <div className="grid grid-cols-5 gap-1">
          {CHAINS.map((chain) => {
            const isActive = chain.id === active;
            const b = balances[chain.id];
            return (
              <button
                key={chain.id}
                onClick={() => setActive(chain.id)}
                className={`hw-button flex flex-col items-center gap-1 rounded px-1 py-2 border transition-colors ${
                  isActive
                    ? "border-white/25 bg-white/5"
                    : "border-transparent hover:border-white/10"
                }`}
                style={{ fontFamily: "Chakra Petch" }}
                aria-pressed={isActive}
              >
                <span
                  className={`led ${b?.status === "loading" ? "led-blink" : ""}`}
                  style={{
                    backgroundColor: chain.color,
                    boxShadow: isActive ? `0 0 6px ${chain.color}` : "none",
                    opacity: isActive ? 1 : 0.45,
                  }}
                />
                <span
                  className={`text-[9px] tracking-[0.1em] ${
                    isActive ? "text-foreground" : "text-muted-foreground"
                  }`}
                >
                  {chain.name}
                </span>
                <span
                  className={`font-mono text-[9px] tabular-nums ${
                    isActive ? "vfd-text" : "text-muted-foreground/70"
                  }`}
                >
                  {fmtShort(b)}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ---- active chain balance ---- */}
      <div className="vfd-panel rounded-md p-4">
        <div className="flex items-center justify-between mb-1">
          <span className="engraved-label">
            {activeChain.name} BALANCE · MAINNET
          </span>
          <button
            onClick={() => loadBalance(activeChain, true)}
            className="hw-button text-muted-foreground hover:text-foreground"
            title="Refresh balance"
            aria-label="Refresh balance"
          >
            <RefreshCw
              className={`h-3.5 w-3.5 ${
                activeBalance?.status === "loading" ? "animate-spin" : ""
              }`}
            />
          </button>
        </div>
        {activeBalance?.status === "error" ? (
          <div className="text-destructive text-sm font-mono">
            RPC ERROR: {activeBalance.message}
          </div>
        ) : (
          <div className="vfd-text text-3xl font-medium">
            {fmt(activeChain, activeBalance)}{" "}
            <span className="text-base opacity-70">{activeChain.ticker}</span>
          </div>
        )}
      </div>

      {/* ---- active chain address ---- */}
      <div className="vfd-panel rounded-md p-4">
        <div className="flex items-center justify-between mb-1.5">
          <span className="engraved-label">{activeChain.name} ADDRESS</span>
          <button
            onClick={copyAddress}
            className="hw-button flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground tracking-wider"
          >
            {copied ? (
              <Check className="h-3.5 w-3.5 text-vfd-green" />
            ) : (
              <Copy className="h-3.5 w-3.5" />
            )}
            {copied ? "COPIED" : "COPY"}
          </button>
        </div>
        <div className="vfd-text-green text-sm break-all leading-relaxed">
          {activeAddress}
        </div>
        {activeChain.addressKind === "eth" && activeChain.id !== "eth" && (
          <p className="text-[10px] text-muted-foreground mt-1.5 tracking-wide">
            EVM CHAIN — SHARES THE ETHEREUM ADDRESS, SEPARATE BALANCE
          </p>
        )}
      </div>

      {/* ---- send / receive transport panel ---- */}
      <SendReceivePanel
        chain={activeChain}
        keys={wallet.chains}
        balance={activeBalance?.status === "ok" ? activeBalance.value : null}
        onSent={() => loadBalance(activeChain, true)}
      />

      {/* ---- disc metadata ---- */}
      <div className="vfd-panel rounded-md p-4 space-y-2.5">
        <div>
          <span className="engraved-label">DISC LABEL</span>
          <div className="vfd-text text-sm mt-0.5">{wallet.label}</div>
        </div>
        <div>
          <span className="engraved-label">
            MEDIA FINGERPRINT · SHA-256 · {wallet.entryCount} ENTRIES
          </span>
          <div className="font-mono text-[11px] text-muted-foreground break-all leading-relaxed mt-0.5">
            {wallet.fingerprintHex}
          </div>
        </div>
      </div>
    </div>
  );
}
