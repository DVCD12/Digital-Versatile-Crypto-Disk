/**
 * DiscWallet — CompactDisc
 * Y2K Optical Deck style: the disc is the only polychrome object on screen.
 * Iridescent conic-gradient surface, slow idle spin, fast blur while reading.
 */

interface CompactDiscProps {
  state: "idle" | "reading" | "loaded";
  size?: number;
}

export default function CompactDisc({ state, size = 280 }: CompactDiscProps) {
  const spinClass =
    state === "reading"
      ? "disc-spin-fast"
      : state === "loaded"
        ? "disc-spin-slow"
        : "disc-spin-idle";

  return (
    <div
      className="relative select-none"
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      {/* ambient glow under disc */}
      <div
        className="absolute inset-0 rounded-full transition-opacity duration-500"
        style={{
          boxShadow:
            state === "reading"
              ? "0 0 80px 8px oklch(0.8 0.16 75 / 0.25), 0 24px 48px rgba(0,0,0,0.6)"
              : "0 0 50px 2px oklch(0.7 0.1 250 / 0.12), 0 24px 48px rgba(0,0,0,0.6)",
        }}
      />
      {/* the disc */}
      <div className={`absolute inset-0 rounded-full ${spinClass}`}>
        {/* iridescent data surface */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: `
              conic-gradient(
                from 0deg,
                #b8c4d0 0deg, #d9b8f0 40deg, #9fd8f5 80deg,
                #c7f0c0 120deg, #f5e3a8 160deg, #f0b8c8 200deg,
                #a8c8f5 240deg, #d0f0e0 280deg, #e8c0f0 320deg, #b8c4d0 360deg
              )`,
          }}
        />
        {/* radial sheen making it read as metal */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: `
              radial-gradient(circle at 35% 30%,
                rgba(255,255,255,0.55) 0%, rgba(255,255,255,0.12) 22%,
                rgba(0,0,0,0.05) 45%, rgba(0,0,0,0.28) 100%)`,
          }}
        />
        {/* fine data-track grooves */}
        <div
          className="absolute inset-0 rounded-full opacity-40"
          style={{
            background: `repeating-radial-gradient(circle at 50% 50%,
              rgba(255,255,255,0.06) 0px, rgba(0,0,0,0.06) 1px,
              rgba(255,255,255,0.06) 2px)`,
          }}
        />
        {/* inner clear ring */}
        <div
          className="absolute rounded-full"
          style={{
            inset: "34%",
            background:
              "radial-gradient(circle, rgba(210,218,228,0.95) 0%, rgba(180,190,205,0.9) 60%, rgba(150,160,175,0.95) 100%)",
            boxShadow: "inset 0 0 8px rgba(0,0,0,0.25)",
          }}
        />
        {/* hub hole — shows chassis through it */}
        <div
          className="absolute rounded-full"
          style={{
            inset: "43%",
            background: "oklch(0.13 0.005 260)",
            boxShadow:
              "inset 0 2px 6px rgba(0,0,0,0.9), 0 1px 0 rgba(255,255,255,0.15)",
          }}
        />
      </div>
      {/* motion-blur streak overlay during read (non-spinning) */}
      {state === "reading" && (
        <div
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            background:
              "conic-gradient(from 90deg, transparent 0deg, rgba(255,255,255,0.18) 25deg, transparent 60deg, transparent 180deg, rgba(255,255,255,0.12) 205deg, transparent 240deg)",
          }}
        />
      )}
      {/* laser dot while reading */}
      {state === "reading" && (
        <div
          className="absolute rounded-full led-blink"
          style={{
            width: 6,
            height: 6,
            left: "50%",
            top: "78%",
            background: "#ff3b30",
            boxShadow: "0 0 10px 3px rgba(255,59,48,0.8)",
          }}
        />
      )}
    </div>
  );
}
