/**
 * DiscWallet — DriveBay
 * Slot-loading optical drive visual.
 *
 * Key illusion: the disc must appear to enter the thin slot OPENING, not
 * pass behind the bezel plate. To achieve that:
 *   - The disc is rendered ON TOP of the bezel (higher z-index), so the
 *     bezel can never occlude it.
 *   - The disc's clipping container starts exactly at the slot line, so
 *     the ONLY place the disc can disappear is through the slot mouth.
 * As the disc travels up, everything above the slot line vanishes while the
 * rest stays in front of the bezel plate — exactly like a car slot-in
 * player swallowing a disc.
 */
import CompactDisc from "@/components/CompactDisc";

interface DriveBayProps {
  state: "idle" | "reading" | "loaded";
  size?: number;
}

// Bezel layout constants (px)
const BEZEL_H = 46; // total bezel height
const SLOT_Y = 24; // y of the slot line (bottom lip of the slot mouth) within the bezel
const DISC_GAP = 14; // resting gap between bezel bottom and disc top

export default function DriveBay({ state, size = 264 }: DriveBayProps) {
  const inserted = state === "reading" || state === "loaded";
  // Fraction of the disc swallowed past the slot line.
  // reading: ~62% in, lower arc visible and spinning; loaded: fully in.
  const travel = state === "loaded" ? 1.03 : state === "reading" ? 0.62 : 0;

  // At rest, the disc top sits (BEZEL_H - SLOT_Y) + DISC_GAP px below the
  // slot line. Moving up by that amount brings the disc's top edge to the
  // slot; each extra px disappears inside.
  const restToSlot = BEZEL_H - SLOT_Y + DISC_GAP;
  const upBy = inserted ? restToSlot + size * travel : 0;

  return (
    <div
      className="relative select-none flex flex-col items-center"
      style={{ width: size + 88 }}
      aria-hidden="true"
    >
      {/* ===== SLOT BEZEL (behind the disc) ===== */}
      <div
        className="relative z-0 w-full rounded-md"
        style={{
          height: BEZEL_H,
          background:
            "linear-gradient(180deg, oklch(0.24 0.006 260), oklch(0.17 0.006 260) 55%, oklch(0.13 0.005 260))",
          boxShadow:
            "0 6px 14px rgba(0,0,0,0.55), inset 0 1px 0 rgba(255,255,255,0.09), inset 0 -1px 0 rgba(0,0,0,0.6)",
          border: "1px solid rgba(255,255,255,0.07)",
        }}
      >
        {/* the slot mouth — its bottom lip sits on the slot line (SLOT_Y) */}
        <div
          className="absolute left-1/2 -translate-x-1/2 rounded-full"
          style={{
            top: SLOT_Y - 9,
            width: size + 28,
            height: 9,
            background:
              "linear-gradient(180deg, #000 0%, oklch(0.09 0.004 260) 100%)",
            boxShadow:
              "inset 0 2px 5px rgba(0,0,0,0.95), 0 1px 0 rgba(255,255,255,0.08)",
          }}
        >
          {/* slot glow while media is in transit / docked */}
          <div
            className="absolute inset-x-2 top-[2px] h-[3px] rounded-full transition-opacity duration-500"
            style={{
              background:
                "linear-gradient(90deg, transparent, oklch(0.8 0.16 75 / 0.85), transparent)",
              opacity: state === "reading" ? 1 : state === "loaded" ? 0.35 : 0,
              filter: "blur(1px)",
            }}
          />
        </div>
        {/* bezel engraving + drive LED */}
        <div className="absolute left-3 bottom-1.5 flex items-center gap-1.5">
          <div
            className={`led ${
              state === "reading"
                ? "led-on led-blink"
                : state === "loaded"
                  ? "led-on"
                  : "led-off"
            }`}
            style={{ width: 5, height: 5 }}
          />
          <span className="engraved-label" style={{ fontSize: 8 }}>
            DW-1000
          </span>
        </div>
        <span
          className="engraved-label absolute right-3 bottom-1.5"
          style={{ fontSize: 8 }}
        >
          SLOT-IN · 24X
        </span>
      </div>

      {/* ===== DISC (in front of the bezel, clipped at the slot line) ===== */}
      {/* This clipping window's top edge is the slot line. The disc renders
          ABOVE the bezel (z-10), so nothing occludes it — the slot line is
          the only boundary where it can vanish. */}
      <div
        className="absolute left-0 right-0 z-10 flex justify-center"
        style={{
          top: SLOT_Y,
          height: BEZEL_H - SLOT_Y + DISC_GAP + size + 24,
          overflow: "hidden",
          pointerEvents: "none",
        }}
      >
        <div
          style={{
            marginTop: restToSlot,
            transform: `translateY(${-upBy}px)`,
            transition: inserted
              ? "transform 1.15s cubic-bezier(0.65, 0, 0.35, 1)"
              : "transform 0.7s cubic-bezier(0.23, 1, 0.32, 1)",
            willChange: "transform",
          }}
        >
          <CompactDisc state={state} size={size} />
        </div>
      </div>

      {/* darkening shade just below the slot lip, drawn over the disc, to
          sell the depth of the opening as the disc passes through */}
      <div
        className="absolute left-1/2 -translate-x-1/2 z-20 transition-opacity duration-300"
        style={{
          top: SLOT_Y,
          width: size + 28,
          height: 12,
          background:
            "linear-gradient(180deg, rgba(0,0,0,0.85), rgba(0,0,0,0))",
          opacity: inserted ? 1 : 0,
          pointerEvents: "none",
        }}
      />

      {/* spacer so the layout reserves room for the resting disc */}
      <div style={{ height: DISC_GAP + size + 24 }} />
    </div>
  );
}
