/**
 * DiscWallet — icon re-exports for the deck UI.
 * lucide-react has no "Eject" icon, so we draw a minimal one matching
 * the Y2K Optical Deck's engraved transport-glyph style.
 */
import type { SVGProps } from "react";
export { Check, Copy, Disc3, FolderOpen, RefreshCw } from "lucide-react";

export function Eject(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 5l7 8H5l7-8z" />
      <line x1="5" y1="17" x2="19" y2="17" />
    </svg>
  );
}
