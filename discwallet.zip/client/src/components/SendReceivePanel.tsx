/**
 * DiscWallet — SEND / RECEIVE transport panel.
 * Vintage DVD-deck styling: raised brushed-metal transport buttons that sink
 * into the faceplate when pressed, VFD-green inset inputs, engraved labels.
 *
 * RECEIVE → QR code + address for the active chain.
 * SEND    → recipient + amount form, client-side signing with the
 *           disc-derived key, broadcast through the server relay.
 * BTC is receive-only (UTXO signing out of scope).
 */
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import QRCode from "qrcode";
import { Check, Copy } from "@/components/deck-icons";
import { ChainId, ChainInfo, MultiChainKeys, addressForChain } from "@shared/chains";
import { canSend, sendFromDisc, validateRecipient, SendResult } from "@/lib/send";

type PanelMode = "closed" | "receive" | "send";
type SendStage = "form" | "confirm" | "sending" | "done";

interface Props {
  chain: ChainInfo;
  keys: MultiChainKeys;
  balance: number | null;
  onSent?: () => void;
}

export default function SendReceivePanel({ chain, keys, balance, onSent }: Props) {
  const [mode, setMode] = useState<PanelMode>("closed");
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [stage, setStage] = useState<SendStage>("form");
  const [sendError, setSendError] = useState<string | null>(null);
  const [result, setResult] = useState<SendResult | null>(null);

  const address = addressForChain(keys, chain);
  const sendable = canSend(chain.id);

  // Reset the panel whenever the chain (or disc) changes.
  useEffect(() => {
    setMode("closed");
    setRecipient("");
    setAmount("");
    setStage("form");
    setSendError(null);
    setResult(null);
  }, [chain.id, address]);

  // Render the QR code when RECEIVE opens.
  useEffect(() => {
    if (mode !== "receive") return;
    let cancelled = false;
    QRCode.toDataURL(address, {
      margin: 1,
      width: 320,
      color: { dark: "#1a1a1eff", light: "#e8e4d8ff" },
    })
      .then((url) => {
        if (!cancelled) setQrDataUrl(url);
      })
      .catch(() => {
        if (!cancelled) setQrDataUrl(null);
      });
    return () => {
      cancelled = true;
    };
  }, [mode, address]);

  const copyAddress = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(address);
      setCopied(true);
      toast.success(`${chain.name} ADDRESS COPIED`);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("CLIPBOARD UNAVAILABLE");
    }
  }, [address, chain]);

  /* ------------------------------- send ---------------------------------- */

  const validateForm = useCallback((): string | null => {
    const recErr = validateRecipient(chain.id, recipient.trim());
    if (recErr) return recErr;
    if (!/^\d+(\.\d+)?$/.test(amount.trim())) return "INVALID AMOUNT";
    const num = Number(amount);
    if (!(num > 0)) return "AMOUNT MUST BE POSITIVE";
    if (balance !== null && num > balance) return "INSUFFICIENT BALANCE";
    return null;
  }, [chain.id, recipient, amount, balance]);

  const goConfirm = useCallback(() => {
    const err = validateForm();
    if (err) {
      setSendError(err);
      return;
    }
    setSendError(null);
    setStage("confirm");
  }, [validateForm]);

  const doSend = useCallback(async () => {
    setStage("sending");
    setSendError(null);
    try {
      const res = await sendFromDisc({
        chain: chain.id,
        keys,
        recipient: recipient.trim(),
        amount: amount.trim(),
      });
      setResult(res);
      setStage("done");
      toast.success("TRANSACTION BROADCAST");
      onSent?.();
    } catch (e) {
      setStage("confirm");
      setSendError(
        (e instanceof Error ? e.message : "BROADCAST FAILED").toUpperCase().slice(0, 120),
      );
    }
  }, [chain.id, keys, recipient, amount, onSent]);

  const closeSend = useCallback(() => {
    setMode("closed");
    setRecipient("");
    setAmount("");
    setStage("form");
    setSendError(null);
    setResult(null);
  }, []);

  /* ------------------------------- render -------------------------------- */

  return (
    <div className="vfd-panel rounded-md p-3">
      {/* transport button row */}
      <div className="grid grid-cols-2 gap-2.5">
        <button
          onClick={() => setMode(mode === "send" ? "closed" : "send")}
          disabled={!sendable}
          className="deck-button deck-button-amber flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold"
          title={sendable ? `Send ${chain.ticker}` : "Receive-only chain"}
        >
          <SendGlyph className="h-3.5 w-3.5" />
          SEND
        </button>
        <button
          onClick={() => setMode(mode === "receive" ? "closed" : "receive")}
          className="deck-button flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold"
          title={`Receive ${chain.ticker}`}
        >
          <ReceiveGlyph className="h-3.5 w-3.5" />
          RECEIVE
        </button>
      </div>

      {!sendable && mode !== "receive" && (
        <p className="text-[10px] text-muted-foreground tracking-[0.12em] text-center mt-2">
          BITCOIN IS RECEIVE-ONLY ON THIS DECK
        </p>
      )}

      {/* ---------- RECEIVE drawer ---------- */}
      {mode === "receive" && (
        <div className="tray-enter mt-3 pt-3 border-t border-white/8 flex flex-col items-center gap-3">
          <span className="engraved-label">RECEIVE {chain.ticker} · SCAN OR COPY</span>
          {qrDataUrl ? (
            <div className="p-2 rounded bg-[#e8e4d8] shadow-[inset_0_0_0_1px_rgba(0,0,0,0.2),0_2px_8px_rgba(0,0,0,0.5)]">
              <img src={qrDataUrl} alt={`${chain.name} address QR code`} className="h-40 w-40" />
            </div>
          ) : (
            <div className="h-40 w-40 rounded bg-white/5 animate-pulse" />
          )}
          <div className="w-full">
            <div className="vfd-text-green text-[11px] break-all leading-relaxed text-center">
              {address}
            </div>
          </div>
          <button
            onClick={copyAddress}
            className="deck-button flex items-center gap-2 px-5 py-2 text-[11px]"
          >
            {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? "COPIED" : "COPY ADDRESS"}
          </button>
        </div>
      )}

      {/* ---------- SEND drawer ---------- */}
      {mode === "send" && sendable && (
        <div className="tray-enter mt-3 pt-3 border-t border-white/8 flex flex-col gap-3">
          {stage === "form" && (
            <>
              <div>
                <label className="engraved-label block mb-1" htmlFor="dw-recipient">
                  RECIPIENT · {chain.name} ADDRESS
                </label>
                <input
                  id="dw-recipient"
                  className="deck-input w-full px-3 py-2 text-xs"
                  placeholder={chain.id === "sol" ? "BASE58 ADDRESS" : "0x…"}
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  spellCheck={false}
                  autoComplete="off"
                />
              </div>
              <div>
                <label className="engraved-label block mb-1" htmlFor="dw-amount">
                  AMOUNT · {chain.ticker}
                </label>
                <input
                  id="dw-amount"
                  className="deck-input w-full px-3 py-2 text-sm"
                  placeholder="0.000000"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
                  inputMode="decimal"
                  autoComplete="off"
                />
                {balance !== null && (
                  <p className="text-[10px] text-muted-foreground tracking-wider mt-1">
                    AVAILABLE: {balance.toFixed(chain.id === "btc" ? 8 : 6)} {chain.ticker}
                  </p>
                )}
              </div>
              {sendError && (
                <p className="text-destructive text-[11px] font-mono tracking-wide">
                  ⚠ {sendError}
                </p>
              )}
              <div className="grid grid-cols-2 gap-2.5">
                <button onClick={closeSend} className="deck-button px-4 py-2 text-[11px]">
                  CANCEL
                </button>
                <button
                  onClick={goConfirm}
                  className="deck-button deck-button-amber px-4 py-2 text-[11px] font-semibold"
                >
                  REVIEW ▸
                </button>
              </div>
            </>
          )}

          {(stage === "confirm" || stage === "sending") && (
            <>
              <span className="engraved-label">CONFIRM TRANSMISSION</span>
              <div className="rounded bg-black/40 border border-white/8 p-3 space-y-2">
                <div>
                  <span className="engraved-label">SEND</span>
                  <div className="vfd-text text-xl font-medium">
                    {amount} <span className="text-sm opacity-70">{chain.ticker}</span>
                  </div>
                </div>
                <div>
                  <span className="engraved-label">TO</span>
                  <div className="vfd-text-green text-[11px] break-all leading-relaxed">
                    {recipient.trim()}
                  </div>
                </div>
                <div>
                  <span className="engraved-label">NETWORK</span>
                  <div className="font-mono text-xs text-foreground/80">
                    {chain.name} · MAINNET
                  </div>
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground tracking-wide leading-relaxed">
                SIGNED LOCALLY WITH THE DISC-DERIVED KEY. MAINNET TRANSFERS ARE
                IRREVERSIBLE — VERIFY THE RECIPIENT BEFORE TRANSMITTING.
              </p>
              {sendError && (
                <p className="text-destructive text-[11px] font-mono tracking-wide break-all">
                  ⚠ {sendError}
                </p>
              )}
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={() => setStage("form")}
                  disabled={stage === "sending"}
                  className="deck-button px-4 py-2 text-[11px]"
                >
                  ◂ BACK
                </button>
                <button
                  onClick={doSend}
                  disabled={stage === "sending"}
                  className="deck-button deck-button-amber px-4 py-2 text-[11px] font-semibold"
                >
                  {stage === "sending" ? "TRANSMITTING…" : "TRANSMIT"}
                </button>
              </div>
            </>
          )}

          {stage === "done" && result && (
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-2">
                <div className="led led-green" />
                <span className="engraved-label">TRANSMISSION COMPLETE</span>
              </div>
              <div>
                <span className="engraved-label">TX ID</span>
                <div className="vfd-text-green text-[11px] break-all leading-relaxed">
                  {result.id}
                </div>
              </div>
              <a
                href={result.explorerUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="deck-button block text-center px-4 py-2 text-[11px]"
              >
                VIEW ON EXPLORER ↗
              </a>
              <button
                onClick={closeSend}
                className="deck-button px-4 py-2 text-[11px]"
              >
                CLOSE
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* --------------------------- transport glyphs --------------------------- */

function SendGlyph(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 19V5" />
      <path d="M5 12l7-7 7 7" />
    </svg>
  );
}

function ReceiveGlyph(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 5v14" />
      <path d="M19 12l-7 7-7-7" />
    </svg>
  );
}
