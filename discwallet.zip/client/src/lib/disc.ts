/**
 * DiscWallet — disc fingerprinting & Solana wallet derivation
 * Design: Y2K Optical Deck — deterministic, hardware-honest logic layer.
 *
 * Pipeline:
 *   1. Walk a directory (FS Access API handle OR webkitdirectory FileList)
 *      capped at MAX_ENTRIES entries and MAX_DEPTH depth.
 *   2. Collect sorted "path:filesize" strings + volume label.
 *   3. SHA-256 hash the joined result → 32-byte fingerprint.
 *   4. Use fingerprint as ed25519 seed → nacl.sign.keyPair.fromSeed(seed).
 *   5. Base58-encode public key → Solana address.
 */

import nacl from "tweetnacl";
import bs58 from "bs58";
import {
  ChainId,
  MultiChainKeys,
  deriveMultiChain,
} from "@shared/chains";

export const MAX_ENTRIES = 400;
export const MAX_DEPTH = 3;

export interface DiscWallet {
  label: string;
  fingerprintHex: string;
  /** Solana address (primary chain, kept for backwards compatibility). */
  address: string;
  entryCount: number;
  secretKey: Uint8Array;
  /** Hardware-wallet style: every chain derives from the same fingerprint. */
  chains: MultiChainKeys;
}

/* ----------------------------- hashing utils ----------------------------- */

async function sha256(data: Uint8Array): Promise<Uint8Array> {
  const buf = await crypto.subtle.digest(
    "SHA-256",
    data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) as ArrayBuffer,
  );
  return new Uint8Array(buf);
}

export function toHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/**
 * Core derivation: entries ("path:size" strings) + volume label → wallet.
 * Sorting guarantees determinism regardless of directory iteration order.
 */
export async function deriveWallet(
  entries: string[],
  label: string,
): Promise<DiscWallet> {
  const sorted = [...entries].sort();
  const material = `${label}\n${sorted.join("\n")}`;
  const seed = await sha256(new TextEncoder().encode(material));
  const keyPair = nacl.sign.keyPair.fromSeed(seed);
  const chains = deriveMultiChain(seed);
  return {
    label,
    fingerprintHex: toHex(seed),
    address: bs58.encode(keyPair.publicKey),
    entryCount: sorted.length,
    secretKey: keyPair.secretKey,
    chains,
  };
}

/* ------------------- File System Access API (Chrome/Edge) ---------------- */

export function supportsDirectoryPicker(): boolean {
  return typeof window !== "undefined" && "showDirectoryPicker" in window;
}

/**
 * Recursively walk a FileSystemDirectoryHandle, collecting "path:filesize"
 * strings, capped at MAX_ENTRIES entries and MAX_DEPTH depth.
 */
export async function walkDirectoryHandle(
  dir: FileSystemDirectoryHandle,
  onProgress?: (count: number) => void,
): Promise<string[]> {
  const entries: string[] = [];

  async function walk(handle: FileSystemDirectoryHandle, path: string, depth: number) {
    if (depth > MAX_DEPTH || entries.length >= MAX_ENTRIES) return;
    // Collect and sort child names first for deterministic traversal order
    const children: { name: string; handle: FileSystemHandle }[] = [];
    // @ts-expect-error async iterator on directory handles
    for await (const [name, child] of handle.entries()) {
      children.push({ name, handle: child });
      if (children.length >= MAX_ENTRIES * 2) break; // safety valve on huge dirs
    }
    children.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));

    for (const { name, handle: child } of children) {
      if (entries.length >= MAX_ENTRIES) return;
      const childPath = path ? `${path}/${name}` : name;
      try {
        if (child.kind === "file") {
          const file = await (child as FileSystemFileHandle).getFile();
          entries.push(`${childPath}:${file.size}`);
          onProgress?.(entries.length);
        } else if (child.kind === "directory") {
          entries.push(`${childPath}/:dir`);
          onProgress?.(entries.length);
          await walk(child as FileSystemDirectoryHandle, childPath, depth + 1);
        }
      } catch {
        // Unreadable entry (permissions, transient IO) — skip deterministically
      }
    }
  }

  await walk(dir, "", 1);
  return entries;
}

/**
 * Poll check: returns true if the directory handle is still readable
 * (disc still inserted). Attempts a shallow read of the directory.
 */
export async function isHandleReadable(
  dir: FileSystemDirectoryHandle,
): Promise<boolean> {
  try {
    // Try to read the first entry — throws if media was ejected
    // @ts-expect-error async iterator on directory handles
    const it = dir.entries()[Symbol.asyncIterator]();
    await it.next();
    return true;
  } catch {
    return false;
  }
}

/* --------------- Fallback: <input webkitdirectory> (one-shot) ------------- */

/**
 * Build entries from a FileList produced by <input type="file" webkitdirectory>.
 * webkitRelativePath starts with the root folder name (the volume label).
 */
export function entriesFromFileList(files: FileList): {
  entries: string[];
  label: string;
} {
  const entries: string[] = [];
  let label = "UNTITLED DISC";
  const dirsSeen = new Set<string>();

  const list = Array.from(files)
    .map((f) => ({ rel: f.webkitRelativePath || f.name, size: f.size }))
    .sort((a, b) => (a.rel < b.rel ? -1 : a.rel > b.rel ? 1 : 0));

  for (const { rel, size } of list) {
    const parts = rel.split("/");
    if (parts.length > 1) label = parts[0];
    // Strip the root folder name so paths match FS Access API output
    const inner = parts.length > 1 ? parts.slice(1) : parts;
    // depth = number of path segments; cap at MAX_DEPTH
    if (inner.length > MAX_DEPTH) continue;
    // Record intermediate directories like the recursive walker does
    for (let d = 1; d < inner.length; d++) {
      const dirPath = inner.slice(0, d).join("/") + "/";
      if (!dirsSeen.has(dirPath) && entries.length < MAX_ENTRIES) {
        dirsSeen.add(dirPath);
        entries.push(`${dirPath}:dir`);
      }
    }
    if (entries.length >= MAX_ENTRIES) break;
    entries.push(`${inner.join("/")}:${size}`);
  }

  return { entries: entries.slice(0, MAX_ENTRIES), label };
}

/* ------------------------------ simulation ------------------------------- */

const SIM_DISCS: { label: string; files: [string, number][] }[] = [
  {
    label: "MIXTAPE_2003",
    files: [
      ["TRACK01.MP3", 4718592],
      ["TRACK02.MP3", 5242880],
      ["TRACK03.MP3", 3932160],
      ["PLAYLIST.M3U", 512],
      ["COVER/FRONT.JPG", 204800],
      ["COVER/BACK.JPG", 198656],
    ],
  },
  {
    label: "BACKUP_VOL_7",
    files: [
      ["DOCS/RESUME.DOC", 38912],
      ["DOCS/TAXES_2002.XLS", 71680],
      ["PHOTOS/IMG_0001.JPG", 1048576],
      ["PHOTOS/IMG_0002.JPG", 983040],
      ["PHOTOS/IMG_0003.JPG", 1122304],
      ["README.TXT", 1024],
      ["SYSTEM/RESTORE.BIN", 8388608],
    ],
  },
  {
    label: "GAME_DISC_1998",
    files: [
      ["SETUP.EXE", 1572864],
      ["DATA/LEVELS.PAK", 52428800],
      ["DATA/SOUNDS.PAK", 31457280],
      ["DATA/TEXTURES.PAK", 41943040],
      ["AUTORUN.INF", 128],
      ["MANUAL.PDF", 2097152],
    ],
  },
  {
    label: "PHOTO_ARCHIVE_04",
    files: [
      ["2004/SUMMER/BEACH_01.JPG", 1310720],
      ["2004/SUMMER/BEACH_02.JPG", 1245184],
      ["2004/WINTER/SNOW_01.JPG", 1179648],
      ["INDEX.HTM", 4096],
      ["THUMBS.DB", 65536],
    ],
  },
];

let simCursor = Math.floor(Math.random() * SIM_DISCS.length);

/** Returns entries + label for a rotating simulated disc. */
export function nextSimulatedDisc(): { entries: string[]; label: string } {
  const disc = SIM_DISCS[simCursor % SIM_DISCS.length];
  simCursor++;
  const entries = disc.files.map(([p, s]) => `${p}:${s}`);
  return { entries, label: disc.label };
}

/* ------------------------------ Solana RPC ------------------------------- */

const RPC_URL = "https://api.mainnet-beta.solana.com";

/** Fetch SOL balance (in SOL) for an address via getBalance JSON-RPC. */
export async function fetchBalance(address: string): Promise<number> {
  const res = await fetch(RPC_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: 1,
      method: "getBalance",
      params: [address],
    }),
  });
  if (!res.ok) throw new Error(`RPC HTTP ${res.status}`);
  const json = await res.json();
  if (json.error) throw new Error(json.error.message || "RPC error");
  const lamports: number = json.result?.value ?? 0;
  return lamports / 1_000_000_000;
}

/**
 * Fallback: fetch SOL balance through the app's server relay, used when the
 * public RPC rejects the browser origin (HTTP 403). Uses a plain GET-style
 * tRPC call to avoid pulling the whole trpc client into this module.
 */
export async function fetchBalanceViaRelay(address: string): Promise<number> {
  const input = encodeURIComponent(
    JSON.stringify({ json: { address } }),
  );
  const res = await fetch(`/api/trpc/solana.getBalance?input=${input}`, {
    method: "GET",
    headers: { "Content-Type": "application/json" },
  });
  if (!res.ok) throw new Error(`Relay HTTP ${res.status}`);
  const json = await res.json();
  const sol = json?.result?.data?.json?.sol;
  if (typeof sol !== "number") {
    throw new Error(
      json?.error?.json?.message || "Relay returned unexpected response",
    );
  }
  return sol;
}

/* --------------------------- multi-chain relay ---------------------------- */

/**
 * Fetch a chain balance through the server relay (balances.<chain>).
 * All chains are read-only queries; nothing about the wallet is persisted.
 */
export async function fetchChainBalance(
  chain: ChainId,
  address: string,
): Promise<number> {
  const input = encodeURIComponent(JSON.stringify({ json: { address } }));
  const res = await fetch(`/api/trpc/balances.${chain}?input=${input}`, {
    method: "GET",
    headers: { "Content-Type": "application/json" },
  });
  if (!res.ok) throw new Error(`Relay HTTP ${res.status}`);
  const json = await res.json();
  const balance = json?.result?.data?.json?.balance;
  if (typeof balance !== "number") {
    throw new Error(
      json?.error?.json?.message || "Relay returned unexpected response",
    );
  }
  return balance;
}
