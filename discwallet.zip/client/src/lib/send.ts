/**
 * DiscWallet — client-side send flows.
 *
 * All signing happens HERE in the browser with the disc-derived keys.
 * The server relay only prepares chain parameters (blockhash / nonce / fees)
 * and broadcasts the pre-signed raw transaction.
 */

import { ChainId, MultiChainKeys } from "@shared/chains";
import {
  buildEip1559Transfer,
  buildSolanaTransfer,
  isValidEvmAddress,
  isValidSolAddress,
  parseAmount,
} from "@shared/tx";

async function relayGet<T>(path: string, input?: unknown): Promise<T> {
  const qs =
    input !== undefined
      ? `?input=${encodeURIComponent(JSON.stringify({ json: input }))}`
      : "";
  const res = await fetch(`/api/trpc/${path}${qs}`, { method: "GET" });
  const json = await res.json();
  if (!res.ok || json?.error) {
    throw new Error(json?.error?.json?.message || `Relay HTTP ${res.status}`);
  }
  return json?.result?.data?.json as T;
}

async function relayPost<T>(path: string, input: unknown): Promise<T> {
  const res = await fetch(`/api/trpc/${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ json: input }),
  });
  const json = await res.json();
  if (!res.ok || json?.error) {
    throw new Error(json?.error?.json?.message || `Relay HTTP ${res.status}`);
  }
  return json?.result?.data?.json as T;
}

export interface SendResult {
  /** Transaction signature / hash. */
  id: string;
  /** Block-explorer URL for the transaction. */
  explorerUrl: string;
}

/** Explorer links per chain. */
export const EXPLORERS: Record<ChainId, (id: string) => string> = {
  sol: (id) => `https://solscan.io/tx/${id}`,
  eth: (id) => `https://etherscan.io/tx/${id}`,
  btc: (id) => `https://blockstream.info/tx/${id}`,
  polygon: (id) => `https://polygonscan.com/tx/${id}`,
  base: (id) => `https://basescan.org/tx/${id}`,
};

export function validateRecipient(chain: ChainId, address: string): string | null {
  if (chain === "sol") {
    return isValidSolAddress(address) ? null : "INVALID SOLANA ADDRESS";
  }
  if (chain === "btc") {
    return "BITCOIN SEND NOT SUPPORTED";
  }
  return isValidEvmAddress(address) ? null : "INVALID 0x ADDRESS";
}

/** Chains that support sending from the deck. */
export function canSend(chain: ChainId): boolean {
  return chain !== "btc";
}

export async function sendFromDisc(params: {
  chain: ChainId;
  keys: MultiChainKeys;
  recipient: string;
  amount: string; // decimal string, e.g. "0.05"
}): Promise<SendResult> {
  const { chain, keys, recipient, amount } = params;

  if (chain === "sol") {
    const lamports = parseAmount(amount, 9);
    if (lamports <= BigInt(0)) throw new Error("Amount must be positive");
    const { blockhash } = await relayGet<{ blockhash: string }>(
      "transactions.solPrepare",
    );
    const { rawBase64 } = buildSolanaTransfer({
      fromSecretKey: keys.sol.secretKey,
      toAddress: recipient,
      lamports,
      recentBlockhash: blockhash,
    });
    const { signature } = await relayPost<{ signature: string }>(
      "transactions.solBroadcast",
      { rawBase64 },
    );
    return { id: signature, explorerUrl: EXPLORERS.sol(signature) };
  }

  if (chain === "eth" || chain === "polygon" || chain === "base") {
    const value = parseAmount(amount, 18);
    if (value <= BigInt(0)) throw new Error("Amount must be positive");
    const prep = await relayGet<{
      nonce: string;
      chainId: number;
      maxPriorityFeePerGas: string;
      maxFeePerGas: string;
      gasLimit: string;
    }>("transactions.evmPrepare", { chain, address: keys.eth.address });

    const { rawHex } = buildEip1559Transfer({
      privateKey: keys.eth.privateKey,
      chainId: BigInt(prep.chainId),
      nonce: BigInt(prep.nonce),
      maxPriorityFeePerGas: BigInt(prep.maxPriorityFeePerGas),
      maxFeePerGas: BigInt(prep.maxFeePerGas),
      gasLimit: BigInt(prep.gasLimit),
      to: recipient,
      value,
    });
    const { hash } = await relayPost<{ hash: string }>(
      "transactions.evmBroadcast",
      { chain, rawHex },
    );
    return { id: hash, explorerUrl: EXPLORERS[chain](hash) };
  }

  throw new Error("Sending is not supported on this chain");
}
