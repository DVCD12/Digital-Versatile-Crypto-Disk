import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { balancesRouter } from "./balances";
import { transactionsRouter } from "./transactions";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  /**
   * Solana JSON-RPC relay.
   * The public mainnet RPC (api.mainnet-beta.solana.com) rejects many browser
   * origins with HTTP 403, so getBalance is relayed through this server.
   * Read-only; no keys or wallets are ever stored.
   */
  solana: router({
    getBalance: publicProcedure
      .input(z.object({ address: z.string().min(32).max(44) }))
      .query(async ({ input }) => {
        const res = await fetch("https://api.mainnet-beta.solana.com", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            jsonrpc: "2.0",
            id: 1,
            method: "getBalance",
            params: [input.address],
          }),
        });
        if (!res.ok) {
          throw new Error(`Solana RPC HTTP ${res.status}`);
        }
        const json = (await res.json()) as {
          result?: { value: number };
          error?: { message?: string };
        };
        if (json.error) {
          throw new Error(json.error.message || "Solana RPC error");
        }
        const lamports = json.result?.value ?? 0;
        return { lamports, sol: lamports / 1_000_000_000 };
      }),
  }),

  /** Multi-chain balance relays (SOL / ETH / BTC / Polygon / Base). */
  balances: balancesRouter,

  /** Transaction prep + broadcast relays (client signs locally). */
  transactions: transactionsRouter,
});

export type AppRouter = typeof appRouter;
