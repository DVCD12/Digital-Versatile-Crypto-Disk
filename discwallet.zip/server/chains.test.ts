import { describe, expect, it } from "vitest";
import { createHash } from "crypto";
import bs58 from "bs58";
import { CHAINS, addressForChain, deriveMultiChain } from "../shared/chains";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

function fingerprintOf(material: string): Uint8Array {
  return new Uint8Array(createHash("sha256").update(material).digest());
}

describe("multi-chain derivation", () => {
  const fp = fingerprintOf("MIXTAPE_2003\nTRACK01.MP3:4718592");

  it("is deterministic: same fingerprint, same addresses on every chain", () => {
    const a = deriveMultiChain(fp);
    const b = deriveMultiChain(fingerprintOf("MIXTAPE_2003\nTRACK01.MP3:4718592"));
    expect(a.sol.address).toBe(b.sol.address);
    expect(a.eth.address).toBe(b.eth.address);
    expect(a.btc.address).toBe(b.btc.address);
  });

  it("different discs produce different addresses on every chain", () => {
    const a = deriveMultiChain(fp);
    const c = deriveMultiChain(fingerprintOf("OTHER_DISC\nREADME.TXT:1024"));
    expect(a.sol.address).not.toBe(c.sol.address);
    expect(a.eth.address).not.toBe(c.eth.address);
    expect(a.btc.address).not.toBe(c.btc.address);
  });

  it("keeps SOL derivation backwards compatible (ed25519 direct from fingerprint)", async () => {
    const nacl = (await import("tweetnacl")).default;
    const legacy = bs58.encode(nacl.sign.keyPair.fromSeed(fp).publicKey);
    expect(deriveMultiChain(fp).sol.address).toBe(legacy);
  });

  it("produces well-formed addresses per chain format", () => {
    const keys = deriveMultiChain(fp);
    expect(bs58.decode(keys.sol.address)).toHaveLength(32);
    expect(keys.eth.address).toMatch(/^0x[0-9a-fA-F]{40}$/);
    expect(keys.btc.address).toMatch(/^bc1q[02-9ac-hj-np-z]{38}$/);
  });

  it("uses independent keys for ETH and BTC (domain separation)", () => {
    const keys = deriveMultiChain(fp);
    expect(Buffer.from(keys.eth.privateKey).toString("hex")).not.toBe(
      Buffer.from(keys.btc.privateKey).toString("hex"),
    );
  });

  it("EVM chains share the ETH address", () => {
    const keys = deriveMultiChain(fp);
    const polygon = CHAINS.find((c) => c.id === "polygon")!;
    const base = CHAINS.find((c) => c.id === "base")!;
    expect(addressForChain(keys, polygon)).toBe(keys.eth.address);
    expect(addressForChain(keys, base)).toBe(keys.eth.address);
  });

  it("rejects fingerprints that are not 32 bytes", () => {
    expect(() => deriveMultiChain(new Uint8Array(16))).toThrow();
  });
});

describe("balances relay procedures", () => {
  const keys = deriveMultiChain(fingerprintOf("TEST_DISC\nA.TXT:1"));
  const caller = appRouter.createCaller(createPublicContext());

  it("eth relay returns a numeric balance", async () => {
    const { balance } = await caller.balances.eth({ address: keys.eth.address });
    expect(typeof balance).toBe("number");
    expect(balance).toBeGreaterThanOrEqual(0);
  }, 30000);

  it("btc relay returns a numeric balance", async () => {
    const { balance } = await caller.balances.btc({ address: keys.btc.address });
    expect(typeof balance).toBe("number");
    expect(balance).toBeGreaterThanOrEqual(0);
  }, 30000);

  it("polygon relay returns a numeric balance", async () => {
    const { balance } = await caller.balances.polygon({ address: keys.eth.address });
    expect(typeof balance).toBe("number");
  }, 30000);

  it("base relay returns a numeric balance", async () => {
    const { balance } = await caller.balances.base({ address: keys.eth.address });
    expect(typeof balance).toBe("number");
  }, 30000);

  it("sol relay returns a numeric balance", async () => {
    const { balance } = await caller.balances.sol({ address: keys.sol.address });
    expect(typeof balance).toBe("number");
  }, 30000);

  it("rejects malformed addresses", async () => {
    await expect(caller.balances.eth({ address: "not-an-address" })).rejects.toThrow();
    await expect(caller.balances.btc({ address: "1BvBMSEYst" })).rejects.toThrow();
  });
});
