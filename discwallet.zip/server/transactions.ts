/**
 * DiscWallet — transaction relay.
 *
 * The server NEVER sees private keys. The client signs locally with the
 * disc-derived keys and this router only:
 *   1. prepares chain parameters (recent blockhash, nonce, gas fees)
 *   2. relays pre-signed raw transactions to public RPC endpoints
 * (relayed server-side because most public RPCs reject browser origins)
 */

import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";

const FETCH_TIMEOUT_MS = 15_000;

async function fetchWithTimeout(url: string, init?: RequestInit): Promise<Response> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(timer);
  }
}

/* ------------------------------- Solana --------------------------------- */

const SOL_RPCS = [
  "https://api.mainnet-beta.solana.com",
  "https://solana-rpc.publicnode.com",
];

async function solRpc<T>(method: string, params: unknown[]): Promise<T> {
  let lastError: unknown = null;
  for (const url of SOL_RPCS) {
    try {
      const res = await fetchWithTimeout(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
      });
      if (!res.ok) throw new Error(`Solana RPC HTTP ${res.status}`);
      const json = (await res.json()) as { result?: T; error?: { message?: string } };
      if (json.error) throw new Error(json.error.message || "Solana RPC error");
      return json.result as T;
    } catch (e) {
      lastError = e;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("All Solana RPCs failed");
}

/* ----------------------------- EVM (shared) ------------------------------ */

const EVM_RPC: Record<string, string[]> = {
  eth: ["https://eth.llamarpc.com", "https://ethereum-rpc.publicnode.com"],
  polygon: ["https://polygon-rpc.com", "https://polygon-bor-rpc.publicnode.com"],
  base: ["https://mainnet.base.org", "https://base-rpc.publicnode.com"],
};

export const EVM_CHAIN_IDS: Record<string, number> = {
  eth: 1,
  polygon: 137,
  base: 8453,
};

async function evmRpc<T>(
  chain: keyof typeof EVM_RPC,
  method: string,
  params: unknown[],
): Promise<T> {
  let lastError: unknown = null;
  for (const url of EVM_RPC[chain]) {
    try {
      const res = await fetchWithTimeout(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
      });
      if (!res.ok) throw new Error(`EVM RPC HTTP ${res.status}`);
      const json = (await res.json()) as { result?: T; error?: { message?: string } };
      if (json.error) throw new Error(json.error.message || "EVM RPC error");
      return json.result as T;
    } catch (e) {
      lastError = e;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("All EVM RPCs failed");
}

/* -------------------------------- router --------------------------------- */

const evmChain = z.enum(["eth", "polygon", "base"]);
const evmAddress = z.string().regex(/^0x[0-9a-fA-F]{40}$/);

export const transactionsRouter = router({
  /** Recent blockhash needed to build a Solana transaction. */
  solPrepare: publicProcedure.query(async () => {
    const result = await solRpc<{ value: { blockhash: string } }>(
      "getLatestBlockhash",
      [{ commitment: "finalized" }],
    );
    return { blockhash: result.value.blockhash };
  }),

  /** Broadcast a pre-signed base64 Solana transaction. */
  solBroadcast: publicProcedure
    .input(z.object({ rawBase64: z.string().min(1).max(4096) }))
    .mutation(async ({ input }) => {
      const signature = await solRpc<string>("sendTransaction", [
        input.rawBase64,
        { encoding: "base64", preflightCommitment: "confirmed" },
      ]);
      return { signature };
    }),

  /** Nonce + EIP-1559 fee estimates for an EVM chain. */
  evmPrepare: publicProcedure
    .input(z.object({ chain: evmChain, address: evmAddress }))
    .query(async ({ input }) => {
      const [nonceHex, feeHistory, gasPriceHex] = await Promise.all([
        evmRpc<string>(input.chain, "eth_getTransactionCount", [
          input.address,
          "pending",
        ]),
        evmRpc<{ baseFeePerGas?: string[] }>(input.chain, "eth_feeHistory", [
          "0x1",
          "latest",
          [50],
        ]).catch(() => null),
        evmRpc<string>(input.chain, "eth_gasPrice", []),
      ]);

      const gasPrice = BigInt(gasPriceHex ?? "0x0");
      const baseFeeHex = feeHistory?.baseFeePerGas?.slice(-1)[0];
      const baseFee = baseFeeHex ? BigInt(baseFeeHex) : gasPrice;
      // priority tip: 1.5 gwei min, capped at gasPrice
      const tip = BigInt(1_500_000_000);
      const maxPriority = tip < gasPrice ? tip : gasPrice;
      const maxFee = baseFee * BigInt(2) + maxPriority;

      return {
        nonce: nonceHex,
        chainId: EVM_CHAIN_IDS[input.chain],
        maxPriorityFeePerGas: "0x" + maxPriority.toString(16),
        maxFeePerGas: "0x" + maxFee.toString(16),
        gasLimit: "0x5208", // 21000 — plain value transfer
      };
    }),

  /** Broadcast a pre-signed 0x raw EVM transaction. */
  evmBroadcast: publicProcedure
    .input(
      z.object({
        chain: evmChain,
        rawHex: z.string().regex(/^0x[0-9a-fA-F]+$/).max(8192),
      }),
    )
    .mutation(async ({ input }) => {
      const hash = await evmRpc<string>(input.chain, "eth_sendRawTransaction", [
        input.rawHex,
      ]);
      return { hash };
    }),
});
