/**
 * DiscWallet — multi-chain balance relay.
 *
 * All balance queries are read-only and relayed server-side because several
 * public RPC endpoints reject browser origins (CORS / 403). No keys, wallets,
 * or addresses are ever persisted.
 *
 * Endpoints used (free, keyless):
 *   SOL      → https://api.mainnet-beta.solana.com     (getBalance)
 *   ETH      → https://eth.llamarpc.com                (eth_getBalance)
 *   Polygon  → https://polygon-rpc.com                 (eth_getBalance)
 *   Base     → https://mainnet.base.org                (eth_getBalance)
 *   BTC      → https://blockstream.info/api/address/…  (chain_stats)
 */

import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";

const FETCH_TIMEOUT_MS = 12_000;

async function fetchWithTimeout(url: string, init?: RequestInit): Promise<Response> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(timer);
  }
}

/* ------------------------------- Solana --------------------------------- */

async function getSolBalance(address: string): Promise<number> {
  const res = await fetchWithTimeout("https://api.mainnet-beta.solana.com", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: 1,
      method: "getBalance",
      params: [address],
    }),
  });
  if (!res.ok) throw new Error(`Solana RPC HTTP ${res.status}`);
  const json = (await res.json()) as {
    result?: { value: number };
    error?: { message?: string };
  };
  if (json.error) throw new Error(json.error.message || "Solana RPC error");
  return (json.result?.value ?? 0) / 1_000_000_000;
}

/* ----------------------------- EVM (shared) ------------------------------ */

const EVM_RPC: Record<string, string[]> = {
  eth: ["https://eth.llamarpc.com", "https://ethereum-rpc.publicnode.com"],
  polygon: ["https://polygon-rpc.com", "https://polygon-bor-rpc.publicnode.com"],
  base: ["https://mainnet.base.org", "https://base-rpc.publicnode.com"],
};

async function getEvmBalance(chain: keyof typeof EVM_RPC, address: string): Promise<number> {
  let lastError: unknown = null;
  for (const url of EVM_RPC[chain]) {
    try {
      const res = await fetchWithTimeout(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          jsonrpc: "2.0",
          id: 1,
          method: "eth_getBalance",
          params: [address, "latest"],
        }),
      });
      if (!res.ok) throw new Error(`EVM RPC HTTP ${res.status}`);
      const json = (await res.json()) as {
        result?: string;
        error?: { message?: string };
      };
      if (json.error) throw new Error(json.error.message || "EVM RPC error");
      const wei = BigInt(json.result ?? "0x0");
      // Convert wei → ether preserving 9 decimal places of precision
      const gwei = wei / BigInt(1_000_000_000);
      return Number(gwei) / 1_000_000_000;
    } catch (e) {
      lastError = e;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("All EVM RPCs failed");
}

/* -------------------------------- Bitcoin -------------------------------- */

async function getBtcBalance(address: string): Promise<number> {
  const res = await fetchWithTimeout(
    `https://blockstream.info/api/address/${encodeURIComponent(address)}`,
  );
  if (!res.ok) throw new Error(`Blockstream HTTP ${res.status}`);
  const json = (await res.json()) as {
    chain_stats?: { funded_txo_sum: number; spent_txo_sum: number };
    mempool_stats?: { funded_txo_sum: number; spent_txo_sum: number };
  };
  const chain = json.chain_stats ?? { funded_txo_sum: 0, spent_txo_sum: 0 };
  const mempool = json.mempool_stats ?? { funded_txo_sum: 0, spent_txo_sum: 0 };
  const sats =
    chain.funded_txo_sum - chain.spent_txo_sum +
    mempool.funded_txo_sum - mempool.spent_txo_sum;
  return sats / 100_000_000;
}

/* -------------------------------- router --------------------------------- */

const solAddress = z.string().min(32).max(44);
const evmAddress = z.string().regex(/^0x[0-9a-fA-F]{40}$/, "invalid EVM address");
const btcAddress = z.string().regex(/^bc1[02-9ac-hj-np-z]{11,87}$/, "invalid bech32 address");

export const balancesRouter = router({
  sol: publicProcedure
    .input(z.object({ address: solAddress }))
    .query(async ({ input }) => ({ balance: await getSolBalance(input.address) })),

  eth: publicProcedure
    .input(z.object({ address: evmAddress }))
    .query(async ({ input }) => ({ balance: await getEvmBalance("eth", input.address) })),

  polygon: publicProcedure
    .input(z.object({ address: evmAddress }))
    .query(async ({ input }) => ({ balance: await getEvmBalance("polygon", input.address) })),

  base: publicProcedure
    .input(z.object({ address: evmAddress }))
    .query(async ({ input }) => ({ balance: await getEvmBalance("base", input.address) })),

  btc: publicProcedure
    .input(z.object({ address: btcAddress }))
    .query(async ({ input }) => ({ balance: await getBtcBalance(input.address) })),
});
