import { describe, expect, it } from "vitest";
import nacl from "tweetnacl";
import bs58 from "bs58";
import { createHash } from "crypto";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

/** Mirror of client-side derivation (client/src/lib/disc.ts deriveWallet). */
function derive(entries: string[], label: string) {
  const sorted = [...entries].sort();
  const material = `${label}\n${sorted.join("\n")}`;
  const seed = createHash("sha256").update(material).digest();
  const kp = nacl.sign.keyPair.fromSeed(new Uint8Array(seed));
  return { fingerprint: seed.toString("hex"), address: bs58.encode(kp.publicKey) };
}

describe("wallet derivation determinism", () => {
  const entries = [
    "TRACK01.MP3:4718592",
    "COVER/FRONT.JPG:204800",
    "PLAYLIST.M3U:512",
  ];

  it("derives identical wallets regardless of entry order", () => {
    const a = derive(entries, "MIXTAPE_2003");
    const b = derive([entries[2], entries[0], entries[1]], "MIXTAPE_2003");
    expect(a.address).toBe(b.address);
    expect(a.fingerprint).toBe(b.fingerprint);
  });

  it("derives different wallets for different discs", () => {
    const a = derive(entries, "MIXTAPE_2003");
    const c = derive(entries, "OTHER_DISC");
    const d = derive([...entries, "EXTRA.TXT:100"], "MIXTAPE_2003");
    expect(a.address).not.toBe(c.address);
    expect(a.address).not.toBe(d.address);
  });

  it("produces a plausible base58 Solana address", () => {
    const { address } = derive(entries, "MIXTAPE_2003");
    expect(address.length).toBeGreaterThanOrEqual(32);
    expect(address.length).toBeLessThanOrEqual(44);
    expect(bs58.decode(address)).toHaveLength(32);
  });
});

describe("solana.getBalance relay", () => {
  it("returns lamports and sol for a valid address", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const { address } = derive(["A.TXT:1"], "TEST_DISC");
    const result = await caller.solana.getBalance({ address });
    expect(typeof result.lamports).toBe("number");
    expect(result.sol).toBe(result.lamports / 1_000_000_000);
  }, 20000);

  it("rejects malformed addresses", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    await expect(
      caller.solana.getBalance({ address: "short" }),
    ).rejects.toThrow();
  });
});
